from bs4 import BeautifulSoup
import json
import os
import re
import chardet

def extract_text(file, granularity='article'):
    """
    Extracts text from HTML files at different levels of granularity.

    Args:
    file (str): The path to the HTML file.
    granularity (str): The level of granularity to extract text at. Currently supports 'article'.

    Returns:
    dict: A dictionary with the extracted text, keyed by the ID of the HTML element.
    """
    with open(file, 'rb') as f:
        raw_html = f.read()

    # Detect the encoding of the HTML file
    encoding = chardet.detect(raw_html)['encoding']

    # Convert the HTML to UTF-8
    try:
        html = raw_html.decode(encoding, errors='replace')
    except LookupError:
        # If the encoding is not recognized, fall back to UTF-8
        html = raw_html.decode('utf-8', errors='replace')

    # Clean the HTML by removing any non-printable characters
    html = ''.join(c for c in html if c.isprintable() or c.isspace())

    soup = BeautifulSoup(html, 'html.parser')

    if granularity == 'article':
        articles = soup.find_all('div', class_='eli-subdivision', id=lambda x: x and x.startswith('art_'))

        article_text = {}
        for article in articles:
            text = article.get_text()
            text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with a single space
            text = text.replace('\xa0', ' ')  # Replace non-breaking spaces with a regular space
            text = text.strip()  # Remove leading and trailing whitespace
            article_text[article['id']] = text

        return article_text

    else:
        raise ValueError(f"Unsupported granularity: {granularity}")